<?php
// En-tête
$_['heading_title']    = 'Expédition par Article';

// Texte
$_['text_description'] = 'Tarif d\'Expédition par Article';
