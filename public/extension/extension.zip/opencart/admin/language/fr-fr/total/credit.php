<?php
// En-tête
$_['heading_title']    = 'Crédit en Magasin';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié le total de crédit en magasin!';
$_['text_edit']        = 'Modifier le Total de Crédit en Magasin';

// Entrée
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Ordre de Tri';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier le total de crédit en magasin!';
