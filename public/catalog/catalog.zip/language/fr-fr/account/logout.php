<?php
// En-tête
$_['heading_title'] = 'Déconnexion du Compte';

// Texte
$_['text_message']  = '<p>Vous avez été déconnecté de votre compte. Vous pouvez maintenant quitter l\'ordinateur en toute sécurité.</p><p>Votre panier a été sauvegardé, les articles qu\'il contient seront restaurés lorsque vous vous reconnecterez à votre compte.</p>';
$_['text_account']  = 'Compte';
$_['text_logout']   = 'Déconnexion';
