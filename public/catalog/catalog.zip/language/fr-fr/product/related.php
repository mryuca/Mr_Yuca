<?php
// Texte
$_['text_related'] = 'Produits Connexes';
