<?php
// En-tête
$_['heading_title']    = 'Boutiques';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié le module des boutiques!';
$_['text_edit']        = 'Modifier le Module des Boutiques';

// Entrée
$_['entry_admin']      = 'Les Administrateurs Seulement';
$_['entry_status']     = 'Statut';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier le module des boutiques!';
