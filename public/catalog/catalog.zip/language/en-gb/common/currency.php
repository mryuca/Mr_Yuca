<?php
// Text
$_['text_currency']  = 'Currency';

// Error
$_['error_currency'] = 'Warning: Currency is not available!';
