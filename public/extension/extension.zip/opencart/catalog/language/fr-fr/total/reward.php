<?php
// Texte
$_['text_reward']   = 'Points de récompenses (%s)';
$_['text_order_id'] = 'ID de Commande: #%s';
