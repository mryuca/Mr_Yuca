<?php
// Text
$_['text_coupon'] = 'Coupon (%s)';
