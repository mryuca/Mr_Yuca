<?php
// Text
$_['text_model']        = 'Model';
$_['text_subscription'] = 'Subscription';
$_['text_points']       = 'Reward Points';

// Column
$_['column_product']    = 'Product';
$_['column_quantity']   = 'Quantity';
$_['column_price']      = 'Unit Price';
$_['column_total']      = 'Total';
