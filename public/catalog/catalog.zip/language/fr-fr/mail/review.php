<?php
// Texte
$_['text_subject']  = '%s - Avis sur un produit';
$_['text_waiting']  = 'Vous avez un nouvel avis produit en attente.';
$_['text_product']  = 'Produit:';
$_['text_reviewer'] = 'Auteur de l\'avis:';
$_['text_rating']   = 'Note:';
$_['text_review']   = 'Texte de l\'avis:';
