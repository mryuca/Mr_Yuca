<?php
// En-tête
$_['heading_title']    = 'Offres spéciales';

// Texte
$_['text_no_results']  = 'Il n\'y a aucun produit en offre spéciale à afficher.';
$_['text_compare']     = 'Comparateur de produits (%s)';
$_['text_sort']        = 'Trier par';
$_['text_default']     = 'Par défaut';
$_['text_name_asc']    = 'Nom (A - Z)';
$_['text_name_desc']   = 'Nom (Z - A)';
$_['text_price_asc']   = 'Prix (Croissant)';
$_['text_price_desc']  = 'Prix (Décroissant)';
$_['text_rating_asc']  = 'Évaluation (La plus basse)';
$_['text_rating_desc'] = 'Évaluation (La plus élevée)';
$_['text_model_asc']   = 'Modèle (A - Z)';
$_['text_model_desc']  = 'Modèle (Z - A)';
$_['text_limit']       = 'Afficher';
