<?php
// Texte
$_['text_refine']      = 'Affiner la recherche';
$_['text_product']     = 'Produits';
$_['text_no_results']  = 'Aucun produit à afficher dans cette catégorie.';
$_['text_compare']     = 'Comparer les produits (%s)';
$_['text_sort']        = 'Trier par';
$_['text_default']     = 'Par défaut';
$_['text_name_asc']    = 'Nom (A - Z)';
$_['text_name_desc']   = 'Nom (Z - A)';
$_['text_price_asc']   = 'Prix (Croissant)';
$_['text_price_desc']  = 'Prix (Décroissant)';
$_['text_rating_asc']  = 'Évaluation (La plus basse)';
$_['text_rating_desc'] = 'Évaluation (La plus haute)';
$_['text_model_asc']   = 'Modèle (A - Z)';
$_['text_model_desc']  = 'Modèle (Z - A)';
$_['text_limit']       = 'Afficher';
