<?php
// En-tête
$_['heading_title']   = 'Permission Refusée!';

// Texte
$_['text_permission'] = 'Vous n\'avez pas la permission d\'accéder à cette page, veuillez';
