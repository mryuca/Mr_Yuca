<?php
// En-tête
$_['heading_title']    = 'Thème du Magasin par Défaut';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié le Thème du Magasin par Défaut!';
$_['text_edit']        = 'Modifier le Thème du Magasin par Défaut';

// Entrée
$_['entry_status']     = 'Statut';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier le Thème du Magasin par Défaut!';
