<?php
// En-tête
$_['heading_title']    = 'Expédition Gratuite';

// Texte
$_['text_description'] = 'Expédition Gratuite';
