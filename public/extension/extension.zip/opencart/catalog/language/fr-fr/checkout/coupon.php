<?php
// En-tête
$_['heading_title'] = 'Utilisez le Code du Coupon';

// Texte
$_['text_success']  = 'Succès: Votre rabais du coupon a été appliqué!';

// Entrée
$_['entry_coupon']  = 'Entrez votre coupon ici';

// Erreur
$_['error_coupon']  = 'Attention: Le coupon est soit invalide, expiré, ou a atteint sa limite d\'utilisation!';
$_['error_status']  = 'Attention: Les coupons ne sont pas activés dans cette boutique!';
