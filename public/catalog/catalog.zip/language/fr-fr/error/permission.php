<?php
// Texte
$_['text_error'] = 'Vous n\'avez pas la permission d\'accéder à cette page.';
