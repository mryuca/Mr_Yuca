<?php
// Texte
$_['text_subject'] = 'Sécurité';
$_['text_code']    = 'Vous devez entrer le code de sécurité lors de la vérification de sécurité de l\'administration.';
$_['text_ip']      = 'IP:';
$_['text_regards'] = 'Cordialement';
