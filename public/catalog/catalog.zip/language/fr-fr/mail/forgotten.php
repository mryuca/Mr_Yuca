<?php
// Texte
$_['text_subject']  = '%s - Demande de réinitialisation de mot de passe';
$_['text_greeting'] = 'Un nouveau mot de passe a été demandé pour le compte client %s.';
$_['text_change']   = 'Pour réinitialiser votre mot de passe, cliquez sur le lien ci-dessous:';
$_['text_ip']       = 'L\'adresse IP utilisée pour effectuer cette demande était:';

// Bouton
$_['button_reset']  = 'Réinitialiser le mot de passe';
