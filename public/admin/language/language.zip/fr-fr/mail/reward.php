<?php
// Texte
$_['text_subject']  = '%s - Points de récompenses';
$_['text_received'] = 'Vous avez reçu %s points de récompenses!';
$_['text_total']    = 'Votre total de points de récompenses est maintenant de %s.';
