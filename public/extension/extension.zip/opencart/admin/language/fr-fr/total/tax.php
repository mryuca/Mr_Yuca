<?php
// En-tête
$_['heading_title']    = 'Taxes';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié le total taxes!';
$_['text_edit']        = 'Modifier le total Taxes';

// Entrée
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Ordre de Tri';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier le total taxes!';
