<?php
// Texte
$_['text_price'] = 'Prix:';
$_['text_tax']   = 'Hors taxes:';
