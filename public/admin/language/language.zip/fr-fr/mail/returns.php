<?php
// Texte
$_['text_subject']       = '%s - Mise à jour du retour %s';
$_['text_return_id']     = 'ID de retour:';
$_['text_date_added']    = 'Date de retour:';
$_['text_return_status'] = 'Votre retour a été mis à jour avec le statut suivant:';
$_['text_comment']       = 'Les commentaires concernant votre retour sont:';
$_['text_footer']        = 'Veuillez répondre à cet e-mail si vous avez des questions.';
