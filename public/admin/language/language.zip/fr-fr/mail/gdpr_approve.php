<?php
// Texte
$_['text_subject'] = '%s - Demande RGPD approuvée!';
$_['text_request'] = 'Demande de suppression de compte';
$_['text_hello']   = 'Bonjour <strong>%s</strong>,';
$_['text_user']    = 'Utilisateur';
$_['text_gdpr']    = 'Votre demande de suppression de données RGPD a été approuvée et sera traitée dans <strong>%s jours</strong>.';
$_['text_q']       = 'Q. Pourquoi ne supprimons-nous pas vos données immédiatement?';
$_['text_a']       = 'R. Les demandes de suppression de compte seront traitées après <strong>%s jours</strong> afin que les remboursements, litiges ou détections de fraude puissent être finalisés.';
$_['text_delete']  = 'Vous recevrez un e-mail vous informant lorsque votre compte aura été supprimé.';
$_['text_thanks']  = 'Merci,';
