<?php
// Texte
$_['text_reward']  = 'Utiliser des points de récompenses';

// Entrée
$_['entry_reward'] = 'Utiliser des points de récompenses';
