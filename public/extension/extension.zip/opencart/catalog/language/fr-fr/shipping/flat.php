<?php
// En-tête
$_['heading_title']    = 'Taux d\'Expédition Forfaitaire';

// Texte
$_['text_description'] = 'Tarif d\'Expédition Forfaitaire';
