<?php
// En-tête
$_['heading_title']    = 'Points de Récompenses';

// Texte
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Succès: Vous avez modifié les points de récompenses!';
$_['text_edit']        = 'Modifier les Points de Récompenses';

// Entrée
$_['entry_status']     = 'Statut';
$_['entry_sort_order'] = 'Ordre de Tri';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'avez pas la permission de modifier les points de récompenses!';
