<?php
// Texte
$_['text_name']       = 'France';
$_['text_loading']    = 'Chargement...';

// Bouton
$_['button_continue'] = 'Continuer';
$_['button_back']     = 'Dos';

// Erreur
$_['error_exception'] = "Code d'erreur (%s)\u{a0}: %s dans %s sur la ligne %s";
