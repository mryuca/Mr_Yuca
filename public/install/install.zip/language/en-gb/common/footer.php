<?php
// Text
$_['text_project']       = 'Project Homepage';
$_['text_documentation'] = 'Documentation';
$_['text_support']       = 'Support Forums';
$_['text_footer']        = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' All Rights Reserved.';
