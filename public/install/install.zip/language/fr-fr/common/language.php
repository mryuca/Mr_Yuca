<?php
// Texte
$_['text_language'] = 'Langue';
