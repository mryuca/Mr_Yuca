<?php
// Heading
$_['heading_title'] = 'Blog';
