<?php
// Texte
$_['text_subject']              = '%s - Commande %s - Abonnement annulé';
$_['text_received']             = 'Vous avez reçu une annulation d\'abonnement.';
$_['text_orders_id']            = 'ID de commande:';
$_['text_subscription_id']      = 'ID de l\'abonnement:';
$_['text_date_added']           = 'Date d\'ajout:';
$_['text_subscription_status']  = 'Statut de l\'abonnement:';
$_['text_comment']              = 'Les commentaires pour votre abonnement sont:';
$_['text_canceled']             = 'Succès: Le profil d\'abonnement a été annulé!';
