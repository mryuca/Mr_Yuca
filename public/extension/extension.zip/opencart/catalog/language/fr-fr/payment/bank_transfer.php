<?php
// En-tête
$_['heading_title']    = 'Virements Banquaires';

// Texte
$_['text_instruction'] = 'Instructions des Virements Banquaires';
$_['text_description'] = 'Veuillez svp transférer le montant total au compte banquaire suivant.';
$_['text_payment']     = 'Votre commande sera livrée lors de la réception de votre paiement.';
