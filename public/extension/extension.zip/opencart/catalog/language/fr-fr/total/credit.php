<?php
// Texte
$_['text_credit']   = 'Crédit en Magasin';
$_['text_order_id'] = 'ID de Commande: #%s';
