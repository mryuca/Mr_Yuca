<?php
// En-tête
$_['heading_title']    = 'Anti-Fraude';

// Texte
$_['text_success']     = 'Succès: Vous avez modifié les paramètres anti-fraude!';
$_['text_list']        = 'Liste Anti-Fraude';

// Colonne
$_['column_name']      = 'Nom Anti-Fraude';
$_['column_status']    = 'Statut';
$_['column_action']    = 'Action';

// Erreur
$_['error_permission'] = 'Attention: Vous n\'êtes pas autorisé à modifier les paramètres anti-fraude!';
$_['error_extension']  = 'Attention: L\'extension n\'existe pas!';
