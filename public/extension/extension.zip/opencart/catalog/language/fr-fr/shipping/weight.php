<?php
// En-tête
$_['heading_title'] = 'Expédition par Poids de Matériaux';

// Texte
$_['text_weight']   = 'Poids:';
