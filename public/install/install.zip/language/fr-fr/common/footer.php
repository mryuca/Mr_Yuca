<?php
// Texte
$_['text_project']       = 'Page d\'accueil du projet';
$_['text_documentation'] = 'Documentation';
$_['text_support']       = 'Forums d\'assistance';
$_['text_footer']        = '<a href="https://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Tous droits réservés.';
