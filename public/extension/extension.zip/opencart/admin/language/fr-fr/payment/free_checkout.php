<?php
// En-tête
$_['heading_title']      = 'Paiements Gratuits';

// Texte
$_['text_extension']     = 'Extensions';
$_['text_success']       = 'Succès: Vous avez modifié les forfaits des paiements gratuits!';
$_['text_edit']          = 'Modifier les forfaits des paiements gratuits';

// Entrée
$_['entry_order_status'] = 'Statut de la Commande';
$_['entry_status']       = 'Statut';
$_['entry_sort_order']   = 'Ordre de Tri';

// Erreur
$_['error_permission']   = 'Attention: Vous n\'avez pas la permission de modifier les forfaits des paiements gratuits!';
