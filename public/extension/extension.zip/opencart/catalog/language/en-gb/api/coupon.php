<?php
// Text
$_['text_success']   = 'Success: Your coupon discount has been applied!';

// Error
$_['error_customer'] = 'Warning: Customer details required!';
$_['error_product']  = 'Warning: Products required!';
$_['error_coupon']   = 'Warning: Coupon is either invalid, expired or reached its usage limit!';
$_['error_status']   = 'Warning: Coupons are not enabled on this store!';
$_['error_confirm']  = 'Warning: Please check the coupon form carefully for errors!';
