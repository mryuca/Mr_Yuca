<?php
// Text
$_['text_success']    = 'Success: Affiliate commission will be applied to this order!';
$_['text_remove']     = 'Success: Your affiliate commission has been removed!';

// Error
$_['error_affiliate'] = 'Warning: Affiliate could not be found!';
$_['error_order']     = 'Warning: Sub-Total needs to be above 0 for commission to be applied!';
