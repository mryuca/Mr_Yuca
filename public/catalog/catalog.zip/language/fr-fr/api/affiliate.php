<?php
// Texte
$_['text_success']    = 'Succès: La commission d\'affiliation sera appliquée à cette commande!';
$_['text_remove']     = 'Succès: Votre commission d\'affiliation a été supprimée!';

// Erreur
$_['error_affiliate'] = 'Attention: L\'affilié n\'a pas pu être trouvé!';
$_['error_order']     = 'Attention: Le sous-total doit être supérieur à 0 pour que la commission soit appliquée!';
