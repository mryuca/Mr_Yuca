<?php
// En-tête
$_['heading_title']     = 'Démarrage';

// Texte
$_['text_success']      = 'Succès: Vous avez modifié le démarrage!';
$_['text_list']         = 'Liste de démarrage';
$_['text_info']         = 'Information de démarrage';

// Colonne
$_['column_code']       = 'Code de démarrage';
$_['column_sort_order'] = 'Ordre de tri';
$_['column_action']     = 'Action';

// Entrée
$_['entry_description'] = 'Description';

// Erreur
$_['error_permission']  = 'Attention: Vous n\'avez pas la permission de modifier le démarrage!';
