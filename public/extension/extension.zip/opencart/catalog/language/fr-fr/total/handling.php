<?php
// Texte
$_['text_handling'] = 'Frais de Manutention';
