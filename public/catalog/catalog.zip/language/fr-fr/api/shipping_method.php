<?php
// Texte
$_['text_success']           = 'Succès: La méthode d\'expédition a été définie!';

// Erreur
$_['error_customer']         = 'Attention: Les détails du client sont requis!';
$_['error_shipping_address'] = 'Attention: L\'adresse d\'expédition est requise!';
$_['error_shipping']         = 'Attention: Aucun produit ne nécessite d\'expédition';
$_['error_no_shipping']      = 'Attention: Aucune option d\'expédition n\'est disponible!';
$_['error_shipping_method']  = 'Attention: La méthode d\'expédition est requise!';
