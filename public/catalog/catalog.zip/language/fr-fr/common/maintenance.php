<?php
// En-tête
$_['heading_title']    = 'Maintenance';

// Texte
$_['text_maintenance'] = 'Maintenance';
$_['text_message']     = '<h1 style="text-align:center;">Nous effectuons actuellement une maintenance programmée. <br/>Nous serons de retour dès que possible. Merci de revenir bientôt.</h1>';
