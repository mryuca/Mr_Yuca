<?php
// Texte
$_['text_subject']      = '%s - Commande %s';
$_['text_received']     = 'Vous avez reçu une commande.';
$_['text_order_id']     = 'ID de la commande:';
$_['text_date_added']   = 'Date d\'ajout:';
$_['text_order_status'] = 'Statut de la commande:';
$_['text_product']      = 'Produits:';
$_['text_total']        = 'Totaux:';
$_['text_comment']      = 'Les commentaires pour votre commande sont:';
