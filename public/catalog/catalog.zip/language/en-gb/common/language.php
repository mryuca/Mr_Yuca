<?php
// Text
$_['text_language'] = 'Language';

// Error
$_['error_language'] = 'Warning: Language is not available!';
