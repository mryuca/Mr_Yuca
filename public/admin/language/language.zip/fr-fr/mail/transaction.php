<?php
// Texte
$_['text_subject']  = '%s - Crédit d\'affiliation';
$_['text_received'] = 'Vous avez reçu un crédit de %s!';
$_['text_total']    = 'Votre montant total de crédit est maintenant de %s.';
$_['text_credit']   = 'Votre crédit peut être déduit de votre prochain achat.';
