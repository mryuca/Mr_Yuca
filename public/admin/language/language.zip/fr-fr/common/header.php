<?php
// En-tête
$_['heading_title']          = 'OpenCart';

// Texte
$_['text_notification']      = 'Notifications';
$_['text_notification_all']  = 'Afficher tout';
$_['text_notification_none'] = 'Aucune notification';
$_['text_profile']           = 'Votre Profil';
$_['text_store']             = 'Magasins';
$_['text_help']              = 'Aide';
$_['text_homepage']          = 'Page d\'Accueil OpenCart';
$_['text_support']           = 'Forum de Support';
$_['text_documentation']     = 'Documentation';
$_['text_logout']            = 'Déconnexion';
