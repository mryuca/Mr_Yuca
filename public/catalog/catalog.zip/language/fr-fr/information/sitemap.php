<?php
// En-tête
$_['heading_title']    = 'Plan du site';

// Texte
$_['text_special']     = 'Offres spéciales';
$_['text_account']     = 'Mon compte';
$_['text_edit']        = 'Informations du compte';
$_['text_password']    = 'Mot de passe';
$_['text_address']     = 'Carnet d\'adresses';
$_['text_history']     = 'Historique des commandes';
$_['text_download']    = 'Téléchargements';
$_['text_cart']        = 'Panier';
$_['text_checkout']    = 'Commander';
$_['text_search']      = 'Recherche';
$_['text_information'] = 'Informations';
$_['text_contact']     = 'Contactez-nous';
