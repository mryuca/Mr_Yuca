<?php
// Heading
$_['heading_title'] = 'Weight Based Shipping';

// Text
$_['text_weight']   = 'Weight:';
