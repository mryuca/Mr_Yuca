<?php
$_['text_related'] = 'Related Products';
