<?php
// En-tête
$_['heading_title']    = 'Trouvez votre marque préférée';

// Texte
$_['text_brand']       = 'Marque';
$_['text_index']       = 'Index des marques:';
$_['text_no_results']  = 'Il n\'y a aucun produit à afficher.';
$_['text_compare']     = 'Comparateur de produits (%s)';
$_['text_sort']        = 'Trier par';
$_['text_default']     = 'Par défaut';
$_['text_name_asc']    = 'Nom (A - Z)';
$_['text_name_desc']   = 'Nom (Z - A)';
$_['text_price_asc']   = 'Prix (Croissant)';
$_['text_price_desc']  = 'Prix (Décroissant)';
$_['text_rating_asc']  = 'Évaluation (la plus basse)';
$_['text_rating_desc'] = 'Évaluation (la plus haute)';
$_['text_model_asc']   = 'Modèle (A - Z)';
$_['text_model_desc']  = 'Modèle (Z - A)';
$_['text_limit']       = 'Afficher';
