<?php
// Texte
$_['text_search'] = 'Rechercher';
